package it.dani.selfhomeapplication;

import android.Manifest;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;

public class IO extends Thread {
    private String ip;
    private String mode;
    private String type;
    private String obj;
    private String value;

    private String result;

    public IO(String ip, String mode, String type, String obj, String value)
    {
        this.ip = ip;
        this.mode = mode;
        this.type = type;
        this.obj = obj;
        this.value = value;

        this.result = "";
    }

    @Override
    public void run() {
        try {
            System.out.println("START");

            DatagramSocket sock = new DatagramSocket();
            byte[] buffer = new byte[256];
            DatagramPacket pack = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(this.ip), 4000);
            ByteArrayOutputStream sockOutByte = new ByteArrayOutputStream();
            BufferedWriter sockOut = new BufferedWriter(new OutputStreamWriter(sockOutByte));

            pack.setData((this.mode + ";" + this.type + ";" + this.obj + ";" + this.value + "\0").getBytes());
            sock.send(pack);

            buffer = new byte[256];
            pack.setData(buffer);
            sock.setSoTimeout(3000);
            sock.receive(pack);
            ByteArrayInputStream sockInByte = new ByteArrayInputStream(pack.getData());
            BufferedReader sockIn = new BufferedReader(new InputStreamReader(sockInByte));

            StringBuilder response = new StringBuilder();
            char car = '\0';

            while ((car = (char) sockIn.read()) != '\0') response.append(car);

            this.result(response.toString());
            System.out.println("Response = " + response);

        } catch(SocketTimeoutException e) {
            this.result("Timeout");
        } catch (Exception e) {
            this.result("Errore");
            e.printStackTrace();
        }
    }

    String result(String str)
    {
        if(str == null)
        {
            return this.result;
        }
        else
        {
            this.result = str;
            return null;
        }
    }
}
