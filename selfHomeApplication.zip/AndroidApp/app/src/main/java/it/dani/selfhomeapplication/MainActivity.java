package it.dani.selfhomeapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnKeyListener {
    private EditText ipText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.ipText = (EditText)findViewById(R.id.ipAddressText);

        Button sala = (Button)findViewById(R.id.sala);
        Button padr = (Button)findViewById(R.id.padronale);
        Button grp1 = (Button)findViewById(R.id.giov);

        sala.setOnClickListener(this);
        padr.setOnClickListener(this);
        grp1.setOnClickListener(this);
    }

    @Override
    public void onClick(View view)
    {
        Button button = (Button) view;
        String mode = "SET";
        String type = null;
        String obj = null;
        String value = "1";

        if(button.getText().toString().equals("sala")) { type = "GRUP"; obj = "sala"; }
        else if(button.getText().toString().equals("camera giovani")) { type = "DISP"; obj = "lampadina camera giovani"; }
        else if(button.getText().toString().equals("camera padronale")) { type = "DISP"; obj = "lampadina camera padronale"; }

        IO io  = new IO(this.ipText.getText().toString(),mode,type,obj,value);
        io.start();

        try
        {
            io.join();
            Toast.makeText(this,io.result(null),Toast.LENGTH_SHORT).show();
        } catch(InterruptedException e) {
            Toast.makeText(this,"ERRORE COMANDO",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onKey(View v, int keyCode, KeyEvent event) {


        return false;
    }
}
